from django.db import models

# Create your models here.
class DesignationModel(models.Model):
    designation = models.CharField(max_length=30)
    department = models.CharField(max_length=40)

    def __str__(self):
        return self.designation


class StudentModel(models.Model):
    desig = models.ForeignKey(DesignationModel, on_delete=models.CASCADE)
    registration = models.CharField(max_length=15)
    year = models.CharField(max_length=20)
    semister = models.CharField(max_length=30)

class MarksEntry(models.Model):
    # register = models.ForeignKey(StudentModel, on_delete=models.CASCADE)
    register = models.CharField(max_length=15)
    f_n = models.CharField(max_length=20, default="none")
    l_n = models.CharField(max_length=30, default="none")
    se = models.CharField(max_length=5, default='F')
    python = models.CharField(max_length=5, default='F')
    os = models.CharField(max_length=5, default='F')
    toc = models.CharField(max_length=5, default='F')
    dbms = models.CharField(max_length=5, default='F')
    grade = models.CharField(max_length=5,default='F')
    sgpa = models.FloatField(default=0)

    def __str__(self):
        return self.register
    
