from django.contrib import admin
from .models import DesignationModel, StudentModel, MarksEntry
# Register your models here.

admin.site.register(DesignationModel)
admin.site.register(StudentModel)
admin.site.register(MarksEntry)