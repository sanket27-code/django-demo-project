from django.shortcuts import render, redirect, reverse
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm 
from .forms import CreateUserForm
from django.contrib import messages
from .models import MarksEntry

# Create your views here.

def home_page(request):
    return render(request, 'Result/home.html')

def register_page(request):
    form = CreateUserForm
    if request.method == 'POST':
        user = CreateUserForm(request.POST)
        if user.is_valid:
            user.save()
            messages.success(request, 'Your account have been created succesfully')
            return redirect('register')
    return render(request, 'Result/register.html', {'form':form})

def login_page(request):
    form = AuthenticationForm(request, data= request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile')
        else:
            messages.info(request, "username or password is incorrect!")
    return render(request, 'Result/login.html', {'form':form})


def profile_page(request):
    details = MarksEntry.objects.all()
    length = len(details)
    cont = {'details':details, 'length':length}
    return render(request, 'Result/profile.html', cont)

def logout_page(request):
    logout(request)
    return redirect('home')

def edit_page(request, id):
    details = MarksEntry.objects.get(id=id)
    return render(request, 'Result/edit.html', {'details':details})

def update_page(request, id):
    if request.method == 'POST':
        data = MarksEntry.objects.get(id=id)
        data.register = request.POST.get('reg_no')
        data.f_n = request.POST.get('f_n')
        data.l_n = request.POST.get('l_n')
        data.se = request.POST.get('se')
        data.python = request.POST.get('python')
        data.os = request.POST.get('os')
        data.toc = request.POST.get('toc')
        data.dbms = request.POST.get('dbms')

        se_credit = int(request.POST.get('se-credit'))
        python_credit = int(request.POST.get('python-credit'))
        os_credit = int(request.POST.get('os-credit'))
        toc_credit = int(request.POST.get('toc-credit'))
        dbms_credit = int(request.POST.get('dbms-credit'))

        se = grade_to_digit(data.se)
        python = grade_to_digit(data.python)
        os = grade_to_digit(data.os)
        toc = grade_to_digit(data.toc)
        dbms =grade_to_digit(data.dbms)

        total_credit = se_credit + python_credit + os_credit + toc_credit + dbms_credit
        sgpa = (se*se_credit)+(python*python_credit)+(os*os_credit)+(toc*toc_credit)+(dbms*dbms_credit)
        sgpa = round(sgpa/total_credit,2)

        data.grade = grading(sgpa)
        data.sgpa = sgpa
        data.save()
        return redirect('profile')


def delete_page(request, id):
    detail = MarksEntry.objects.get(id=id)
    detail.delete()
    return redirect('profile')

def upload_page(request):
    if request.method == 'POST':
        data = MarksEntry()
        data.register = request.POST.get('reg_no')
        data.f_n = request.POST.get('f_n')
        data.l_n = request.POST.get('l_n')
        data.se = request.POST.get('se')
        data.python = request.POST.get('python')
        data.os = request.POST.get('os')
        data.toc = request.POST.get('toc')
        data.dbms = request.POST.get('dbms')

        se_credit = int(request.POST.get('se-credit'))
        python_credit = int(request.POST.get('python-credit'))
        os_credit = int(request.POST.get('os-credit'))
        toc_credit = int(request.POST.get('toc-credit'))
        dbms_credit = int(request.POST.get('dbms-credit'))

        se = grade_to_digit(data.se)
        python = grade_to_digit(data.python)
        os = grade_to_digit(data.os)
        toc = grade_to_digit(data.toc)
        dbms =grade_to_digit(data.dbms)

        total_credit = se_credit + python_credit + os_credit + toc_credit + dbms_credit
        sgpa = (se*se_credit)+(python*python_credit)+(os*os_credit)+(toc*toc_credit)+(dbms*dbms_credit)
        sgpa = round(sgpa/total_credit,2)

        data.grade = grading(sgpa)
        data.sgpa = sgpa
        data.save()
        return redirect('profile')
    return render(request, 'Result/createmarks.html')

def statistics_page(request):
    record = MarksEntry.objects.all()
    return render(request, 'Result/statistics.html', {'record':record})

def grade_card_page(request, id):
    record = MarksEntry.objects.get(id=id)
    return render(request, 'Result/grade_card.html', {'record':record})


def grade_to_digit(a):
    grade = {'A+':10,'A':9,'B+':8,'B':7,'C+':6,'C':5,'F':4}
    return grade[a]

def grading(z):
    if (z > 9) and (z < 10):
        return 'A+'
    elif (8 < z) and (z <= 9):
        return 'A'
    elif (7 < z) and (z <= 8):
        return 'B+'
    elif (6 < z) and (z <= 7):
        return 'B'
    elif (5 < z) and (z <= 6):
        return 'C+'
    elif (4 <= z) and (z <= 5):
        return 'C'
    else:
        return 'F'