from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('profile/', views.profile_page, name='profile'),
    path('', views.home_page, name='home'),
    path('register/', views.register_page, name='register'),
    path('login/', views.login_page, name='login'),
    path('logout/', views.logout_page, name='logout'),
    path('edit/<int:id>', views.edit_page, name='edit'),
    path('update/<int:id>', views.update_page, name='update'),
    path('delete/<int:id>', views.delete_page, name='delete'),
    path('statistics/', views.statistics_page, name='statistics'),
    path('upload/', views.upload_page, name='upload'),
    path('grade_card/<int:id>', views.grade_card_page, name='grade_card'),
    path('oauth/', include('social_django.urls', namespace='social')),
]

